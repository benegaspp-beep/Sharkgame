namespace projeto_jogo__Pedro_vatanabe
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_jogar_Click(object sender, EventArgs e)
        {
            sharkgame game = new sharkgame();
            game.Show(); 
            this.Hide();
        }
    }
}
