﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.ComponentModel;

namespace projeto_jogo__Pedro_vatanabe
{
    public class Bullet : PictureBox
    {
        public int Velocidade { get; set; } = 100;

        public Bullet(int x, int y) 
        {
            Left = x;
            Top = y;
            Size = new System.Drawing.Size(200, 200);
            SizeMode = PictureBoxSizeMode.StretchImage;
            string caminhoimagem = Path.Combine
                (
                    Application.StartupPath,
                    "assets",
                    "motoserra.png"
                
                );
            Image = Image.FromFile ( caminhoimagem );
        }

        public void Mover()
        {
           Left += Velocidade;
        }

        public bool SaiuDaTela()
        {

            return Left + Width > 1920;
        }
    }
}
