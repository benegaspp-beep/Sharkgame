﻿namespace projeto_jogo__Pedro_vatanabe
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            lbl_titulo = new Label();
            btn_jogar = new Button();
            SuspendLayout();
            // 
            // lbl_titulo
            // 
            lbl_titulo.AutoSize = true;
            lbl_titulo.Font = new Font("Sitka Heading", 72F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbl_titulo.ForeColor = Color.RoyalBlue;
            lbl_titulo.Location = new Point(310, 93);
            lbl_titulo.Name = "lbl_titulo";
            lbl_titulo.Size = new Size(1279, 208);
            lbl_titulo.TabIndex = 0;
            lbl_titulo.Text = "Jogo do Sharknado";
            lbl_titulo.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // btn_jogar
            // 
            btn_jogar.BackgroundImage = (Image)resources.GetObject("btn_jogar.BackgroundImage");
            btn_jogar.BackgroundImageLayout = ImageLayout.Stretch;
            btn_jogar.Font = new Font("Viner Hand ITC", 28F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_jogar.ForeColor = Color.DarkRed;
            btn_jogar.Location = new Point(695, 412);
            btn_jogar.Name = "btn_jogar";
            btn_jogar.Size = new Size(508, 145);
            btn_jogar.TabIndex = 1;
            btn_jogar.Text = "Jogar";
            btn_jogar.UseVisualStyleBackColor = true;
            btn_jogar.Click += btn_jogar_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1898, 1024);
            Controls.Add(btn_jogar);
            Controls.Add(lbl_titulo);
            DoubleBuffered = true;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Sharknator";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbl_titulo;
        private Button btn_jogar;
    }
}
