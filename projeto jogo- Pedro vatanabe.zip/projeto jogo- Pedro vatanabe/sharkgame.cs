﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projeto_jogo__Pedro_vatanabe
{
    public partial class sharkgame : Form
    {
        private Player jogador;
        public sharkgame()
        {
            InitializeComponent();
            IniciarJogo();
        }

        private void IniciarJogo()
        {
            //instanciar um objeto Player
            jogador = new Player();
            //definir uma posição para o jogador
            jogador.Location = new Point(50, 340);
            //adicionar o Player no formulário
            Controls.Add(jogador);
            //Ativa a verificação das teclas pressionadas
            KeyPreview = true;
            //quando a tecla for pressionada, executa o método keydown
            KeyDown += sharkgame_KeyDown;
        }

        private void sharkgame_KeyDown(object sender, KeyEventArgs e)
        {
            //executa o método mover e passa tecla pressionada
            jogador.Mover(e.KeyCode, ClientSize.Width, ClientSize.Height);

            if (e.KeyCode == Keys.Space)
            {
                Bullet disparo = jogador.Atirar();
                Controls.Add(disparo);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            for(int i= jogador.Balas.Count -1; i>=0; i--) {
                Bullet disparo = jogador.Balas[i];
                disparo.Mover();

                if (disparo.SaiuDaTela())
                {
                    Controls.Remove (disparo);
                    jogador.Balas.RemoveAt(i);
                    disparo.Dispose();
                }
            }
        }   
    }
}
